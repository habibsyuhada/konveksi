<?php $this->load->view('_partial/header');?>
<?php $this->load->view('_partial/top');?> 
<?php $this->load->view($subview);?>
<?php $this->load->view('_partial/footer');?>